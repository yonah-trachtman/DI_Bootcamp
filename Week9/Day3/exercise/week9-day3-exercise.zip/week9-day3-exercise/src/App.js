import logo from './logo.svg';
import './App.css';
import ErrorBoundary from './ErrorBoundary';
import BuggyCounter from './BuggyCounter';
function App() {
  return (
    <>
<ErrorBoundary fallback={<p>Counter 1 is down</p>}>
<BuggyCounter />
<BuggyCounter />
</ErrorBoundary >

<ErrorBoundary fallback={<p>Counter 1 is down</p>}>
<BuggyCounter />
</ErrorBoundary >
<ErrorBoundary fallback={<p>Counter 1 is down</p>}>
<BuggyCounter />
</ErrorBoundary >

<BuggyCounter />
</>
  );
}

export default App;
